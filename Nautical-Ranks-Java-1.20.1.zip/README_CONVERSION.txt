Nautical Ranks - Java Resource Pack (1.20.1)

Converted from the provided Bedrock pack glyph PNGs.

Glyph-to-character mapping (Private Use Area):
- glyph_E2.png -> \uE0E2
- glyph_E5.png -> \uE0E5

Usage: In your plugin/config, use the mapped character codes to display the glyphs.
Example: \uE0E2 (shown above)